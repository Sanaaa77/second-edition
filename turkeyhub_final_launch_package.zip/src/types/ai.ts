export interface StudentProfile {
  gpa: number;
  budget: number;
  major: string;
  degree: "Bachelor" | "Master" | "PhD";
  preferredCity?: string;
  language: "English" | "Turkish" | "Mixed";
  ielts?: number;
  toefl?: number;
  sat?: number;
  yos?: number;
  workExperienceYears?: number;
  scholarshipPreference: boolean;
}

export interface UniversityAdmissionCriteria {
  minGpa: number;
  preferredGpa: number;
  minIelts?: number;
  minSat?: number;
  minYos?: number;
  tuitionFee: number;
  competitiveness: number; // 1-10 (10 being hardest)
}

export interface AdmissionResult {
  universityId: string;
  universityName: string;
  acceptanceProbability: number;
  scholarshipProbability: number;
  estimatedAnnualCost: number;
  strengths: string[];
  weaknesses: string[];
  recommendedImprovements: string[];
  nextBestAction: string;
  reasoning: string;
  pros: string[];
  cons: string[];
}

export interface ScoredUniversity extends AdmissionResult {
  score: number;
}

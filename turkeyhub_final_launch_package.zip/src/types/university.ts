import { DegreeLevel, Language } from "./index";
import { University, Program, Scholarship } from "./database";

export interface UniversityDomain extends University {
  history?: string;
  campus_life?: string;
  video_url?: string;
  gallery_urls?: string[];
  student_photos?: string[];
  official_website?: string;
  social_media?: {
    instagram?: string;
    linkedin?: string;
    twitter?: string;
  };
  facts?: any[];
  rankings?: any;
  career_outcomes?: any;
  student_life?: any;
  admission_reqs?: any;
  programs?: Program[];
  scholarships?: Scholarship[];
}

import { Article, ArticleTranslation, University, City, Program, Scholarship, FAQ } from "./database";

export interface SearchResult {
  universities: Partial<University>[];
  programs: Partial<Program>[];
  articles: Partial<ArticleTranslation>[];
  cities: Partial<City>[];
  scholarships: Partial<Scholarship>[];
  faqs: Partial<FAQ>[];
}

export interface SearchOptions {
  query: string;
  category?: string;
  limit?: number;
  offset?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface ImportResult {
  total: number;
  success: number;
  failed: number;
  errors: Array<{
    batch: number;
    message: string;
    row?: number;
  }>;
  imported_at: string;
  version: string;
}

export interface MetadataModel {
  title: string;
  description: string;
  keywords?: string[];
  canonical_url?: string;
  og_image?: string;
  og_type?: string;
  twitter_card?: string;
  json_ld?: any;
}

export type DegreeLevel = 'Associate' | 'Bachelor' | 'Master' | 'PhD' | 'Medicine' | 'Dentistry' | 'Pharmacy';
export type Language = 'English' | 'Turkish' | 'Mixed';
export type LanguageLevel = 'A1' | 'A2' | 'B1' | 'B2' | 'C1' | 'C2' | 'Academic' | 'IELTS' | 'TOEFL' | 'TOMER';
export type ApplicationStatus = 'Draft' | 'Submitted' | 'Reviewing' | 'Accepted' | 'Rejected' | 'Visa_Processing' | 'Completed';

export interface University {
  id: string;
  name: string;
  slug: string;
  [key: string]: any;
}

export interface City {
  id: string;
  name: string;
  [key: string]: any;
}

export interface Scholarship {
  id: string;
  name: string;
  [key: string]: any;
}

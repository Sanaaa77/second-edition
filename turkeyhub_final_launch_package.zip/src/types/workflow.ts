import { ApplicationStatus, DocumentStatus } from "./database";

export interface ApplicationAuditLog {
  id: string;
  application_id: string;
  changed_by: string;
  previous_status: ApplicationStatus | null;
  new_status: ApplicationStatus;
  action_type: 'STATUS_CHANGE' | 'DOCUMENT_UPLOAD' | 'NOTE_ADDED';
  reason: string | null;
  ip_address: string | null;
  metadata: Record<string, any> | null;
  created_at: string;
}

export interface ApplicationChecklistItem {
  id: string;
  application_id: string;
  label: string;
  type: string;
  priority: 'Low' | 'Normal' | 'High' | 'Urgent';
  is_completed: boolean;
  due_date: string | null;
  required_for_status: ApplicationStatus | null;
}

export type DocumentType = 
  | 'Passport' 
  | 'Diploma' 
  | 'Transcript' 
  | 'CV' 
  | 'SOP' 
  | 'Recommendation_Letter' 
  | 'IELTS' 
  | 'TOEFL' 
  | 'TOMER' 
  | 'Portfolio' 
  | 'Financial_Statement' 
  | 'Insurance' 
  | 'Photo';

export interface HardenedDocument {
  id: string;
  profile_id: string;
  name: string;
  type: DocumentType;
  version: number;
  status: DocumentStatus;
  file_url: string;
  storage_path: string;
  checksum: string | null;
  expiry_date: string | null;
  reject_reason: string | null;
  metadata: Record<string, any> | null;
  created_at: string;
}

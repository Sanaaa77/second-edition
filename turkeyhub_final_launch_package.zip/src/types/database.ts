export type DegreeLevel = "Associate" | "Bachelor" | "Master" | "PhD" | "Medicine" | "Dentistry" | "Pharmacy";
export type ApplicationStatus = 'Draft' | 'Preparing' | 'Ready' | 'Submitted' | 'Review' | 'Interview' | 'Accepted' | 'Rejected' | 'Visa' | 'Completed';
export type VisaStatus = 'Not_Started' | 'Preparing' | 'Submitted' | 'Interview_Scheduled' | 'Approved' | 'Rejected';

export interface Offer {
  id: string;
  application_id: string;
  profile_id: string;
  university_id: string;
  program_id: string;
  offer_type: 'Conditional' | 'Unconditional';
  tuition_deposit_required: number;
  deadline: string;
  file_url: string;
  status: 'Pending' | 'Accepted' | 'Rejected' | 'Expired';
  created_at: string;
}

export interface VisaApplication {
  id: string;
  profile_id: string;
  status: VisaStatus;
  appointment_date: string | null;
  tracking_number: string | null;
  notes: string | null;
}

export interface ApplicationMessage {
  id: string;
  application_id: string;
  sender_id: string;
  message: string;
  attachments: string[] | null;
  is_read: boolean;
  created_at: string;
}
export type DocumentStatus = "Pending" | "Verified" | "Rejected";
export type TaskStatus = "completed" | "pending" | "locked";

export interface Profile {
  id: string;
  first_name: string | null;
  last_name: string | null;
  email: string | null;
  phone: string | null;
  birth_date: string | null;
  nationality: string;
  current_city: string | null;
  gpa: number | null;
  budget: number | null;
  preferred_language: "English" | "Turkish" | "Mixed" | null;
  preferred_major: string | null;
  target_degree: string | null;
  avatar_url: string | null;
  onboarding_completed: boolean;
  current_step: number;
  created_at: string;
  updated_at: string;
  academic_details?: {
    high_school_gpa: number | null;
    bachelor_gpa: number | null;
    master_gpa: number | null;
    top_tier_uni: boolean;
    backlogs: number;
  };
  language_profiles?: {
    ielts: { overall: number | null; listening: number | null; reading: number | null; writing: number | null; speaking: number | null };
    toefl: { overall: number | null };
    tomer: { level: string | null };
    pte: { overall: number | null };
  };
  experience_details?: {
    work_years: number;
    research_projects: number;
    publications: number;
    certificates: string[];
    volunteering: number;
  };
  financial_profile?: {
    annual_budget: number;
    source_of_funds: string;
    bank_statement_ready: boolean;
    scholarship_needed: boolean;
  };
}

export interface AdmissionWeight {
  id: string;
  dimension: string;
  weight: number;
  description: string;
}

export interface StudentPrediction {
  id: string;
  profile_id: string;
  university_id: string | null;
  program_id: string | null;
  admission_probability: number;
  scholarship_probability: number;
  confidence_score: number;
  strengths: string[];
  weaknesses: string[];
  risk_factors: string[];
  last_calculated: string;
}

export interface DreamUniversity {
  id: string;
  profile_id: string;
  university_id: string;
  program_id: string | null;
  priority: number;
  created_at: string;
  university?: University;
  program?: Program;
}

export interface City {
  id: string;
  name: string;
  slug: string;
  living_cost_index: "Low" | "Medium" | "High";
  population: string | null;
  climate: string | null;
  description: string | null;
  image_url: string | null;
  coords: { x: string; y: string } | null;
  created_at: string;
  rent: string;
  dorm: string;
  transport: string;
  food: string;
}

export interface University {
  id: string;
  city_id: string | null;
  name: string;
  slug: string;
  type: "Public" | "Private";
  ranking_global: number | null;
  ranking_local: number | null;
  logo_url: string | null;
  hero_image_url: string | null;
  description: string | null;
  dormitory_available: boolean;
  verified: boolean;
  website_url: string | null;
  created_at: string;
  city?: City; 
  history?: string;
  mission?: string;
  vision?: string;
  campus_life?: string;
  faculties?: Faculty[];
  rankings?: Ranking[];
  university_media?: UniversityMedia[];
  campuses?: Campus[];
  faqs?: FAQ[];
  career_outcomes?: CareerOutcome[];
  admission_requirements?: AdmissionRequirements;
  tuition_fee?: number;
}

export interface AdmissionRequirements {
  gpa: number;
  ielts: number;
  toefl?: number;
  sat?: number;
  tomer?: string;
  documents: string[];
  age_limit?: number;
  work_experience_years?: number;
}

export interface UniversityMedia {
  id: string;
  university_id: string;
  type: 'Image' | 'Video';
  url: string;
  caption: string | null;
  is_hero: boolean;
  order_index: number;
}

export interface Program {
  id: string;
  university_id: string;
  faculty_id?: string;
  name: string;
  degree_level: string | null;
  language: "Turkish" | "English" | "Mixed" | null;
  duration_years: number | null;
  tuition_fee: number | null;
  currency: string;
  requirements: string[] | null;
  created_at: string;
  university?: University;
  curriculum?: any;
  internship_required?: boolean;
  demand_score?: number;
  international_accreditation?: string[];
}

export interface Faculty {
  id: string;
  university_id: string;
  name: string;
  programs?: Program[];
}

export interface Scholarship {
  id: string;
  university_id: string;
  name: string;
  coverage_percentage: number | null;
  description: string | null;
  requirements: string[] | null;
  deadline: string | null;
  created_at: string;
}

export interface Application {
  id: string;
  profile_id: string;
  university_id: string | null;
  program_id: string | null;
  status: ApplicationStatus;
  created_at: string;
  updated_at: string;
  university?: University;
  program?: Program;
}

export interface Document {
  id: string;
  profile_id: string;
  name: string;
  type: string;
  file_url: string;
  status: DocumentStatus;
  rejection_reason: string | null;
  created_at: string;
}

export interface Task {
  id: string;
  profile_id: string;
  label: string;
  status: TaskStatus;
  category: string | null;
  due_date: string | null;
  created_at: string;
}

export interface Notification {
  id: string;
  profile_id: string;
  title: string;
  message: string;
  read: boolean;
  type: string | null;
  created_at: string;
}

export interface Campus {
  id: string;
  university_id: string;
  name: string;
  address: string | null;
  facilities: string[] | null;
  image_url: string | null;
  coords: { x: string; y: string } | null;
  created_at: string;
  updated_at: string;
}

export interface LivingCostDetail {
  id: string;
  city_id: string;
  category: 'Food' | 'Rent' | 'Transport' | 'Utilities';
  item_name: string;
  min_price: number;
  max_price: number;
  currency: string;
  last_updated: string;
}

export interface CareerOutcome {
  id: string;
  university_id: string;
  program_id: string | null;
  employment_rate_6m: number | null;
  avg_starting_salary: number | null;
  top_employers: string[] | null;
  popular_roles: string[] | null;
}

export interface VisaRule {
  id: string;
  country_name: string;
  visa_type: string;
  requirements: string[] | null;
  processing_time_days: number | null;
  fee_amount: number | null;
  fee_currency: string;
  last_verified: string;
}

export interface Article {
  id: string;
  slug: string;
  category: string;
  author_id: string;
  featured_image: string;
  published: boolean;
  view_count: number;
  created_at: string;
  translations?: ArticleTranslation[];
}

export interface ArticleTranslation {
  id: string;
  article_id: string;
  language_code: string;
  title: string;
  content: string;
  excerpt: string;
  meta_title: string;
  meta_description: string;
}

export interface Review {
  id: string;
  university_id: string;
  profile_id: string;
  rating: number;
  comment: string;
  language: string;
  verified: boolean;
  created_at: string;
}

export interface FAQ {
  id: string;
  university_id: string;
  category: string;
  order_index: number;
  translations?: FAQTranslation[];
}

export interface FAQTranslation {
  id: string;
  faq_id: string;
  language_code: string;
  question: string;
  answer: string;
}

export interface Ranking {
  id: string;
  university_id: string;
  provider: string;
  rank: number;
  year: number;
  score: number;
  category: string;
}

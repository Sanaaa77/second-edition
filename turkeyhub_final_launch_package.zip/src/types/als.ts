import { DegreeLevel, LanguageLevel } from './index';

export interface AdmissionMilestone {
  id: string;
  label: string;
  category: 'Academic' | 'Language' | 'Document' | 'Financial';
  impactWeight: number;
  satisfied: boolean;
}

export interface DreamReadiness {
  targetUniversityId: string;
  targetIntakeDate: string;
  overallReadinessScore: number;
  languageReadiness: {
    english: number;
    turkish: number;
    gapToRequirement: string;
  };
  academicReadiness: number;
  documentReadiness: number;
  financialReadiness: number;
}

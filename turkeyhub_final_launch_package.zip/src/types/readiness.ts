import { University, LanguageLevel } from './index';

export type MissionPriority = 'Low' | 'Medium' | 'High' | 'Urgent';

export interface Mission {
  id: string;
  title: string;
  description: string;
  category: 'Language' | 'Document' | 'Academic' | 'Financial';
  xpReward: number;
  readinessImpact: number; // Percent increase in readiness
  completed: boolean;
  dueDate: string;
}

export interface UniversityRequirement {
  id: string;
  label: string;
  isSatisfied: boolean;
  type: 'GPA' | 'Language' | 'Document' | 'Financial' | 'Test';
  currentValue?: any;
  requiredValue?: any;
}

export interface UniversityReadiness {
  universityId: string;
  universityName: string;
  overallScore: number; // 0-100%
  requirements: UniversityRequirement[];
  estimatedPrepWeeks: number;
  nextBestAction: string;
}

export interface Milestone {
  id: string;
  label: string;
  date: string;
  isCompleted: boolean;
  type: 'Application' | 'Exam' | 'Visa' | 'Arrival';
}

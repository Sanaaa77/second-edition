/**
 * Domain Models for TurkeyHub AI Admission Platform
 */

export type DegreeLevel = 'Associate' | 'Bachelor' | 'Master' | 'PhD' | 'Medicine' | 'Dentistry' | 'Pharmacy';
export type Language = 'English' | 'Turkish' | 'Mixed';
export type RiskSeverity = 'Low' | 'Medium' | 'High' | 'Critical';
export type Priority = 'Low' | 'Medium' | 'High' | 'Urgent';
export type Difficulty = 'Easy' | 'Moderate' | 'Hard';

export interface University {
  id: string;
  name: string;
  slug: string;
  cityId: string;
  type: 'Public' | 'Private';
  rankingGlobal: number;
  rankingLocal: number;
  logoUrl: string;
  heroImageUrl: string;
  description: string;
  dormitoryAvailable: boolean;
  verified: boolean;
  websiteUrl: string;
  competitivenessScore: number;
  acceptanceRate: number;
}

export interface Program {
  id: string;
  universityId: string;
  name: string;
  faculty: string;
  degreeLevel: DegreeLevel;
  language: Language;
  durationYears: number;
  tuitionFee: number;
  currency: 'USD' | 'TRY';
  requirements: {
    minGpa: number;
    minIelts?: number;
    minToefl?: number;
    minSat?: number;
    minYos?: number;
    requiredDocuments: string[];
    portfolioRequired: boolean;
    researchExperiencePreferred: boolean;
    workExperiencePreferred: boolean;
  };
}

export interface StudentProfile {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  nationality: string;
  gpa: number;
  budget: number;
  targetDegree: DegreeLevel;
  targetMajor: string;
  preferredLanguage: Language;
  preferredCities: string[];
  ielts?: number;
  toefl?: number;
  sat?: number;
  yos?: number;
  researchExperienceMonths: number;
  workExperienceMonths: number;
  hasSop: boolean;
  recommendationLettersCount: number;
  hasPortfolio: boolean;
  scholarshipPreference: boolean;
  onboardingCompleted: boolean;
}

export interface AdmissionAnalysis {
  score: number;
  probability: number;
  strengths: string[];
  weaknesses: string[];
  reasons: string[];
  breakdown: Record<string, number>;
}

import { University, DegreeLevel, Language } from "./index";

export interface UniversityDetail extends University {
  history?: string;
  facts?: UniversityFact[];
  city_info?: string;
  campus_life?: string;
  video_url?: string;
  gallery_urls?: string[];
  student_photos?: string[];
  exchange_programs?: string[];
  research_centers?: string[];
  career_outcomes?: CareerStats;
  faqs?: { question: string; answer: string }[];
  admission_steps?: string[];
  ielts_req?: number;
  toefl_req?: number;
  tomer_req?: string;
  gpa_req?: number;
}

export interface UniversityFact {
  label: string;
  value: string;
  icon: string;
}

export interface CareerStats {
  employment_rate: number;
  avg_salary: number;
  top_employers: string[];
}

import { University, Program, Profile, Task, Document, Scholarship } from "@/types/database";

export type ReadinessDimensionId = 
  | 'academic' 
  | 'language' 
  | 'financial' 
  | 'documents' 
  | 'visa' 
  | 'research' 
  | 'work' 
  | 'scholarship' 
  | 'timeline' 
  | 'interview' 
  | 'statement' 
  | 'recommendations' 
  | 'portfolio';

export type DimensionStatus = 'at-risk' | 'on-track' | 'excellent' | 'incomplete';

export interface DimensionScore {
  id: ReadinessDimensionId;
  title: string;
  currentScore: number; // 0-100
  targetScore: number; // 0-100
  maxScore?: number;
  weight: number; // 0-1
  status: DimensionStatus;
  missingItems: string[];
  recommendations: string[];
  recommendation?: string;
  gap: number;
  estimatedImprovementGain: number;
  estimatedDaysToImprove: number;
  estImprovementTime?: string;
  estReadinessGain?: number;
}

export interface DecisionReport {
  id: string;
  generatedAt: string;
  profileId: string;
  overallReadiness: number; // 0-100
  admissionProbability: number; // 0-100
  scholarshipProbability: number; // 0-100
  riskScore: number; // 0-100
  confidenceScore: number; // 0-100
  dimensions: Partial<Record<ReadinessDimensionId, DimensionScore>>;
  gapAnalysis: {
    criticalGaps: string[];
    easyWins: string[];
  };
  nextBestAction: {
    label: string;
    impact: number;
    effort: 'Low' | 'Medium' | 'High';
  };
  roadmap: {
    milestone: string;
    date: string;
    completed: boolean;
  }[];
  topMatches?: any[];
  scholarships?: any[];
}

export interface JourneyState {
  profile: Profile | null;
  tasks: Task[];
  documents: Document[];
  scholarships: Scholarship[];
  decisionReport: DecisionReport | null;
  loading: boolean;
  error: string | null;
}

import { DegreeLevel, Language } from './models';

export type LanguageLevel = 'A1' | 'A2' | 'B1' | 'B2' | 'C1' | 'C2' | 'Academic' | 'IELTS' | 'TOEFL' | 'TOMER';

export interface AcademyCourse {
  id: string;
  title: string;
  slug: string;
  description: string;
  language: 'English' | 'Turkish';
  level: LanguageLevel;
  thumbnail_url: string;
  total_lessons: number;
  estimated_hours: number;
  xp_reward: number;
}

export interface AcademyStats {
  profile_id: string;
  total_xp: number;
  daily_streak: number;
  last_lesson_at: string | null;
  total_study_minutes: number;
  english_level: LanguageLevel;
  turkish_level: LanguageLevel;
}

export interface AcademyProgress {
  id: string;
  profile_id: string;
  course_id: string;
  completed_lessons: string[];
  current_level: LanguageLevel;
  last_activity: string;
}

export interface AcademyLesson {
  id: string;
  module_id: string;
  title: string;
  content_json: any;
  order_index: number;
  duration_minutes: number;
  type: 'Video' | 'Audio' | 'Interactive' | 'Quiz' | 'Exercise';
  resources: { label: string; url: string }[];
  xp_reward: number;
}

export interface AcademyExercise {
  id: string;
  lesson_id: string;
  type: 'multiple_choice' | 'fill_in_the_blank' | 'drag_drop' | 'matching' | 'sentence_order' | 'speaking' | 'writing';
  title: string;
  instruction: string;
  content: {
    question: string;
    options?: string[];
    correct_answer: any;
    hint?: string;
    explanation?: string;
  };
  order_index: number;
}

export interface VocabularyWord {
  id: string;
  profile_id: string;
  word: string;
  translation: string;
  example_sentence: string;
  language: 'English' | 'Turkish';
  proficiency_level: number;
  last_reviewed_at: string;
  mastered: boolean;
}

export interface AcademyAchievement {
  id: string;
  name: string;
  description: string;
  icon_url: string;
  category: 'Streak' | 'XP' | 'CourseCompletion' | 'SkillMastery';
  requirement_type: string;
  requirement_value: number;
}

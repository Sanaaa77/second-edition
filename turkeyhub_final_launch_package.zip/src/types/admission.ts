import { ReadinessDimensionId, DimensionStatus, DimensionScore } from "./decision-engine";

export interface AdmissionRequirements {
  gpa: number;
  ielts: number;
  toefl?: number;
  sat?: number;
  tomer?: string;
  documents: string[];
  age_limit?: number;
  work_experience_years?: number;
}

export interface UniversityRequirement {
  university_id: string;
  program_id?: string;
  requirements: AdmissionRequirements;
}

export interface AdmissionAnalysis {
  probability: number;
  confidence: number;
  strengths: string[];
  weaknesses: string[];
  riskFactors: string[];
  nextBestActions: PriorityAction[];
  scores: Record<ReadinessDimensionId, DimensionScore>;
  alternatives?: {
    universities: any[];
    programs: any[];
  };
  backupUniversities?: any[];
  estimatedCostTotal?: number;
}

export interface PriorityAction {
  id: string;
  label: string;
  impact: number;
  effort: 'Low' | 'Medium' | 'High';
  type: 'academic' | 'language' | 'document' | 'financial' | 'other';
  deadline?: string;
}

import { Metadata } from 'next';
import { MetadataModel } from '@/types/knowledge';

export class MetadataService {
  private static readonly DEFAULT_TITLE = 'ترکیه هاب | دستیار هوشمند تحصیل در ترکیه';
  private static readonly DEFAULT_DESC = 'بزرگترین پایگاه داده دانشگاه‌های ترکیه، پذیرش هوشمند و آکادمی زبان.';

  static generate(model: Partial<MetadataModel>): Metadata {
    const title = model.title || this.DEFAULT_TITLE;
    const description = model.description || this.DEFAULT_DESC;

    return {
      title,
      description,
      keywords: model.keywords || ['تحصیل در ترکیه', 'دانشگاه های ترکیه', 'اپلای ترکیه'],
      alternates: {
        canonical: model.canonical_url,
      },
      openGraph: {
        title,
        description,
        images: model.og_image ? [{ url: model.og_image }] : undefined,
        type: model.og_type as any || 'website',
      },
      twitter: {
        card: model.twitter_card as any || 'summary_large_image',
        title,
        description,
        images: model.og_image ? [model.og_image] : undefined,
      },
      robots: 'index, follow',
    };
  }

  static generateUniversityJsonLd(university: any) {
    const translation = university.university_translations?.find((t: any) => t.language_code === 'fa') || {};
    return {
      '@context': 'https://schema.org',
      '@type': 'EducationalOrganization',
      name: translation.name || university.name,
      url: university.website_url,
      address: {
        '@type': 'PostalAddress',
        addressLocality: university.city?.name,
        addressCountry: 'Turkey',
      },
      description: translation.description || university.description,
    };
  }
}
